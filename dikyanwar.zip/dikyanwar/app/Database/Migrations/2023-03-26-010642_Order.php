<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Order extends Migration
{
    public function up()
    {
        //create column name
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'order_id' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true
            ],
            'order_date' => [
                'type' => 'DATE',
                'null' => true
            ],
            'customer_id' => [
                'type' => 'INT',
                'null' => true
            ],
            'promo_code' => [
                'type' => 'VARCHAR',
                'null' => true
            ],
            'amount_discount' => [
                'type' => 'FLOAT',
                'null' => true
            ],
            'net' => [
                'type' => 'FLOAT',
                'null' => true
            ],
            'ppn' => [
                'type' => 'FLOAT',
                'null' => true
            ],
            'total' => [
                'type' => 'FLOAT',
                'null' => true
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ]
        ]);
        //create primary key
        $this->forge->addKey('order_detail_id', TRUE);
        //create table name
        $this->forge->createTable('order_detail', TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('order_detail');
    }
}
