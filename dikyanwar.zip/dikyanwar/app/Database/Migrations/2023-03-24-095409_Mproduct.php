<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Mproduct extends Migration
{
    public function up()
    {
        //create column name
        $this->forge->addField([
            'pcode' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'product_name' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true
            ],
            'price' => [
                'type' => 'FLOAT',
                'null' => true
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ]
        ]);
        //create primary key
        $this->forge->addKey('pcode', TRUE);
        //create table name
        $this->forge->createTable('product', TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('product');
    }
}

//php spark migrate:create Mproduct
//php spark migrate