<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Promo extends Migration
{
    public function up()
    {
        //create column name
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'promo_code' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true
            ],
            'promo_name' => [
                'type' => 'TEXT',
                'null' => true
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ]
        ]);
        //create primary key
        $this->forge->addKey('pcode', TRUE);
        //create table name
        $this->forge->createTable('product', TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('promo');
    }
}
