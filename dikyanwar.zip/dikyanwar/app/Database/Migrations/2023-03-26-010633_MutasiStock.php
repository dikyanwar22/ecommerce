<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class MutasiStock extends Migration
{
    public function up()
    {
        //create column name
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'tgl_mutasi' => [
                'type' => 'DATE',
                'null' => true
            ],
            'pcode' => [
                'type' => 'VARCHAR',
                'null' => true
            ],
            'order_id' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true
            ],
            'type_mutasi' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true
            ],
            'jumlah' => [
                'type' => 'INT',
                'null' => true
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ]
        ]);
        //create primary key
        $this->forge->addKey('id', TRUE);
        //create table name
        $this->forge->createTable('mutasi_stok', TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('mutasi_stok');
    }
}
