<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class OrderDetail extends Migration
{
    public function up()
    {
        //create column name
        $this->forge->addField([
            'order_detail_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'order_id' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true
            ],
            'pcode' => [
                'type' => 'VARCHAR',
                'null' => true
            ],
            'qty' => [
                'type' => 'INT',
                'null' => true
            ],
            'price' => [
                'type' => 'FLOAT',
                'null' => true
            ],
            'subtotal' => [
                'type' => 'FLOAT',
                'null' => true
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => true
            ]
        ]);
        //create primary key
        $this->forge->addKey('order_detail_id', TRUE);
        //create table name
        $this->forge->createTable('order_detail', TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('order_detail');
    }
}
