<?= $this->extend('admin/layout/default'); ?>
<?= $this->section('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Tabel</li>
          <li class="breadcrumb-item active"><?= $title; ?></li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <p></p>
              <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#basicModal">
                Tambah <i class="bi bi-plus-circle"></i>
              </button>
              <p></p>
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">kode</th>
                    <th scope="col">Nama Produk</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach($p as $key => $v) : ?>
                  <tr>
                    <th scope="row"><?= $key+1; ?></th>
                    <td><?= $v['pcode']; ?></td>
                    <td><?= $v['product_name']; ?></td>
                    <td>Rp <?= number_format($v['price'],2,',','.'); ?></td>
                    <td>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#edit<?= $v['pcode']; ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
                        <a href="<?= base_url('produk/delete/'.$v['pcode']); ?>" onclick="return confirm('Yakin Hapus?')" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

<!-- Modal Tambah -->
<div class="modal fade" id="basicModal" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Tambah <?= $title; ?></h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                <form action="<?= base_url('produk/store'); ?>" method="POST" enctype="multipart/form-data" class="row g-3">
                    <div class="modal-body">
                      <!-- Form -->
                <div class="col-12">
                  <label>Nama Produk</label>
                  <input type="text" name="product_name" class="form-control" placeholder="Nama Produk" autofocus="" required="">
                </div>
                <div class="col-12">
                  <label>Harga</label>
                  <input type="number" name="price" class="form-control" placeholder="Rp" required="">
                </div>
                      <!-- Form -->
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>

                  </div>
                </div>
              </div>
<!-- Modal Tambah -->

<!-- Modal Update -->
<?php foreach($p as $key => $k) : ?>
<div class="modal fade" id="edit<?= $k['pcode']; ?>" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Ubah <?= $title; ?></h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                <form action="<?= base_url('produk/edit/'.$k['pcode']); ?>" method="POST" enctype="multipart/form-data" class="row g-3">
                    <div class="modal-body">
                      <!-- Form -->
                <div class="col-12">
                  <label>Nama Produk</label>
                  <input type="text" name="product_name" class="form-control" value="<?= $k['product_name']; ?>" autofocus="" required="">
                </div>
                <div class="col-12">
                  <label>Harga</label>
                  <input type="number" name="price" class="form-control" value="<?= $k['price']; ?>" required="">
                </div>
                      <!-- Form -->
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>

                  </div>
                </div>
              </div>
<?php endforeach; ?>
<!-- Modal Update -->

  </main>
  <!-- End #main -->

  <?= $this->endSection(); ?>