<?= $this->extend('admin/layout/default'); ?>
<?= $this->section('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Tabel</li>
          <li class="breadcrumb-item active"><?= $title; ?></li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">

            <?php if (!empty(session()->getFlashdata('error'))) : ?>
              <p></p>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo session()->getFlashdata('error'); ?>
                    </div>
             <?php endif; ?>
              
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Produk</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach($p as $key => $v) : ?>
                  <tr>
                    <th scope="row"><?= $key+1; ?></th>
                    <td><?= $v['product_name']; ?></td>
                    <td>Rp <?= number_format($v['price'],2,',','.'); ?></td>
                    <td>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#edit<?= $v['pcode']; ?>" class="btn btn-primary btn-sm">Beli</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

<!-- Modal Update -->
<?php foreach($p as $key => $k) : ?>
<div class="modal fade" id="edit<?= $k['pcode']; ?>" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Order Produk</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                <form action="<?= base_url('order-produk'); ?>" method="POST" enctype="multipart/form-data" class="row g-3">
                <?= csrf_field(); ?>
                <div class="modal-body">
                      <!-- Form -->
                <div class="col-12">
                  <label>Nama Produk</label>
                  <input type="text" class="form-control" value="<?= $k['product_name']; ?>" readonly>
                </div>
                <div class="col-12" hidden>
                  <label>Pcode</label>
                  <input type="text" class="form-control" name="pcode" value="<?= $k['pcode']; ?>">
                </div>
                <div class="col-12">
                  <label>Harga</label>
                  <input type="text" class="form-control" value="Rp <?= number_format($k['price'],2,',','.'); ?>" readonly>
                </div>
                <div class="col-12" hidden>
                  <label>Harga</label>
                  <input type="number" class="form-control" name="net" value="<?= $k['price']; ?>" required>
                </div>
                <div class="col-12">
                  <label>Amount Discount</label>
                  <input type="number" class="form-control" name="amount_discount" value="1000" required>
                </div>
                <div class="col-12">
                  <label>PPN</label>
                  <input type="number" class="form-control" name="ppn" value="1900" required>
                </div>
                <div class="col-12">
                  <label>QTY</label>
                  <input type="number" class="form-control" name="qty" value="1" required>
                </div>
                <div class="col-12">
                  <label>Nama Kustomer</label>
                    <select class="form-control" name="customer_id" required="">
                        <option disabled selected>- Pilih -</option>
                        <?php foreach($c as $key => $get) : ?>
                        <option value="<?= $get['customer_id']; ?>"><?= $get['customer_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                  <label>Kode Promo</label>
                  <input type="text" class="form-control" name="promo_code" placeholder="Kode Promo">
                </div>
                      <!-- Form -->
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Order Produk</button>
                    </div>
                </form>

                  </div>
                </div>
              </div>
<?php endforeach; ?>
<!-- Modal Update -->

  </main>
  <!-- End #main -->

  <?= $this->endSection(); ?>