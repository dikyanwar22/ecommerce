<?= $this->extend('admin/layout/default'); ?>
<?= $this->section('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Tabel</li>
          <li class="breadcrumb-item active"><?= $title; ?></li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Produk</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Ubah</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach($stok as $key => $v) : ?>
                  <tr>
                    <th scope="row"><?= $key+1; ?></th>
                    <td><?= $v->product_name; ?></td>
                    <td><?= $v->jumlah; ?></td>
                    <td>
                    <a href="#" data-bs-toggle="modal" data-bs-target="#edit<?= $v->pcode; ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  <!-- Modal Update -->
<?php foreach($stok as $key => $k) : ?>
<div class="modal fade" id="edit<?= $k->pcode; ?>" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Ubah <?= $title; ?></h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                <form action="<?= base_url('stok-update/'.$k->id); ?>" method="POST" enctype="multipart/form-data" class="row g-3">
                    <div class="modal-body">
                      <!-- Form -->
                <div class="col-12">
                  <label>Nama Produk</label>
                  <input type="text" class="form-control" value="<?= $k->product_name; ?>" readonly>
                </div>
                <div class="col-12">
                  <label>Stok</label>
                  <input type="number" name="jumlah" class="form-control" value="<?= $k->jumlah; ?>" required="">
                </div>
                      <!-- Form -->
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>

                  </div>
                </div>
              </div>
<?php endforeach; ?>
<!-- Modal Update -->

  </main>
  <!-- End #main -->

  <?= $this->endSection(); ?>