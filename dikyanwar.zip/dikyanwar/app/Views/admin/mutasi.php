<?= $this->extend('admin/layout/default'); ?>
<?= $this->section('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Tabel</li>
          <li class="breadcrumb-item active"><?= $title; ?></li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Produk</th>
                    <th scope="col">Tgl Mutasi</th>
                    <th scope="col">Type Mutasi</th>
                    <th scope="col">Jumlah</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach($mut as $key => $v) : ?>
                  <tr>
                    <th scope="row"><?= $key+1; ?></th>
                    <td><?= $v->product_name; ?></td>
                    <td><?= date('d F Y', strtotime($v->tgl_mutasi)); ?></td>
                    <td><?= $v->type_mutasi; ?></td>
                    <td><?= $v->jumlah; ?></td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main>
  <!-- End #main -->

  <?= $this->endSection(); ?>