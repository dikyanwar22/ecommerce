<?= $this->extend('admin/layout/default'); ?>
<?= $this->section('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Tabel</li>
          <li class="breadcrumb-item active"><?= $title; ?></li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kode Order</th>
                    <th scope="col">Nama Produk</th>
                    <th scope="col">QTY</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Total</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach($k as $key => $v) : ?>
                  <tr>
                    <th scope="row"><?= $key+1; ?></th>
                    <td><?= $v->order_id; ?></td>
                    <td><?= $v->product_name; ?></td>
                    <td><?= $v->qty; ?></td>
                    <td>Rp <?= number_format($v->price,2,',','.'); ?></td>
                    <td><?php $a = $v->qty; $b = $v->price; $tot = $a*$b; echo "Rp ".number_format($tot,2,',','.'); ?></td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main>
  <!-- End #main -->

  <?= $this->endSection(); ?>