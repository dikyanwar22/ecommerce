  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= site_url('customer'); ?>">
          <i class="bi bi-person"></i>
          <span>Customer</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= site_url('produk'); ?>">
          <i class="bi bi-list"></i>
          <span>Produk</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= site_url('promo'); ?>">
          <i class="bi bi-list"></i>
          <span>Promo</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= site_url('stok'); ?>">
          <i class="bi bi-list"></i>
          <span>Stok</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= site_url('mutasi'); ?>">
          <i class="bi bi-list"></i>
          <span>Mutasi Stok</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?= site_url('order'); ?>">
          <i class="bi bi-list"></i>
          <span>Order</span>
        </a>
      </li>
  
    </ul>

  </aside><!-- End Sidebar-->