  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span><?= date('Y'); ?></span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Created by : <a href="#">Diky Anwar</a>
    </div>
  </footer>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?= $this->include('admin/layout/js'); ?>
