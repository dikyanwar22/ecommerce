<?= $this->extend('admin/layout/default'); ?>
<?= $this->section('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Tabel</li>
          <li class="breadcrumb-item active"><?= $title; ?></li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <p></p>
              <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#basicModal">
                Tambah <i class="bi bi-plus-circle"></i>
              </button>
              <p></p>
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Detail Order</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach($k as $key => $v) : ?>
                  <tr>
                    <th scope="row"><?= $key+1; ?></th>
                    <td><?= $v['customer_name']; ?></td>
                    <td><?= $v['address']; ?></td>
                    <td>
                      <a href="<?= site_url('customer-orderid/'.$v['customer_id']); ?>" class="btn btn-primary btn-sm">
                        <i class="bi bi-search"></i>
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

<!-- Modal Tambah -->
<div class="modal fade" id="basicModal" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Tambah <?= $title; ?></h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                <form action="<?= base_url('customer-add'); ?>" method="POST" enctype="multipart/form-data" class="row g-3">
                    <div class="modal-body">
                      <!-- Form -->
                <div class="col-12">
                  <label>Nama Produk</label>
                  <input type="text" name="customer_name" class="form-control" placeholder="Nama" autofocus="" required="">
                </div>
                <div class="col-12">
                  <label>Alamat</label>
                  <input type="text" name="address" class="form-control" placeholder="Alamat" required="">
                </div>
                      <!-- Form -->
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>

                  </div>
                </div>
              </div>
<!-- Modal Tambah -->

  </main>
  <!-- End #main -->

  <?= $this->endSection(); ?>