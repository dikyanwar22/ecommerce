<?= $this->extend('admin/layout/default'); ?>
<?= $this->section('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Form</li>
          <li class="breadcrumb-item active"><?= $title; ?></li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

        <div class="card">
            <div class="card-body">
              <h5 class="card-title">Form <?= $title; ?></h5>
        <?php if (!empty(session()->getFlashdata('error'))) : ?>
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <?php echo session()->getFlashdata('error'); ?>
            </div>
        <?php endif; ?>
              <!-- Vertical Form -->
              <form action="<?= base_url('pengguna-update/'.session()->get('id')); ?>" method="POST" class="row g-3">
                <div class="col-12">
                  <label class="form-label">Nama Lengkap</label>
                  <input type="text" name="nm" class="form-control" value="<?= session()->get('nm') ?>" required>
                </div>
                <div class="col-12">
                  <label class="form-label">Email</label>
                  <input type="email" name="email" class="form-control" value="<?= session()->get('email') ?>" required>
                </div>
                <div class="col-12">
                  <label class="form-label">Password</label>
                  <input type="password" name="password" placeholder="Password" class="form-control">
                </div>
                <div class="text-center">
                    <button type="button" onclick="window.history.back()" class="btn btn-danger">Kembali</button>
                        &nbsp;&nbsp;
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
              <!-- Vertical Form -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main>
  <!-- End #main -->

  <?= $this->endSection(); ?>