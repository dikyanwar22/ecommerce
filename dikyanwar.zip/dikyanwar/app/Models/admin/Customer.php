<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class Customer extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'customer';
    protected $primaryKey       = 'customer_id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['customer_name', 'address', 'created_at', 'updated_at'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function order_detail($customer_id) {
        $db = \Config\Database::connect();
        $query = "SELECT product.product_name, order_detail.qty, order_detail.price, order_detail.subtotal, order_header.order_id
        FROM order_detail JOIN order_header ON order_header.order_id = order_detail.order_id
        JOIN product ON product.pcode = order_detail.pcode
        WHERE customer_id = '$customer_id'
        GROUP BY order_detail.order_detail_id ORDER BY order_detail.order_detail_id DESC";
        $sql = $db->query($query)->getResult();
        return $sql;
    }

}
