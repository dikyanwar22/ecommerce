<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class Stock extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'stock';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['pcode', 'jumlah', 'created_at', 'updated_at'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function db_viewstock($pcode) {
        $db = \Config\Database::connect();
        $sql = $db->table('stock')
        ->where('pcode',$pcode)
        ->get();
        return $sql->getRow();
    }

    public function db_stok() {
        $db = \Config\Database::connect();
        $query = "SELECT product.product_name, stock.jumlah, stock.pcode, stock.id FROM stock
        INNER JOIN product ON product.pcode = stock.pcode
        GROUP BY stock.id
        ORDER BY stock.id DESC";
        $sql = $db->query($query)->getResult();
        return $sql;
    }

}
