<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class Order extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'order_header';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['order_id', 'order_date', 'customer_id', 'promo_code', 'amount_discount', 'net', 'ppn', 'total', 'created_at', 'updated_at'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function check_kode($promo_code) {
        $db = \Config\Database::connect();
        $query = "SELECT * FROM promo WHERE promo_code = '$promo_code' ";
        $sql = $db->query($query)->getRow();
        return $sql;
    }

    public function order_code() {
        $db = \Config\Database::connect();
        $query = "SELECT max(order_id) as kodeTerbesar FROM order_header ORDER BY id DESC LIMIT 1";
        $sql = $db->query($query)->getRow();
        return $sql;
    }

}
