<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class MutasiStock extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'mutasi_stock';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['tgl_mutasi', 'pcode', 'order_id', 'type_mutasi', 'jumlah', 'created_at', 'updated_at'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function db_mutasi() {
        $db = \Config\Database::connect();
        $query = "SELECT product.product_name, mutasi_stock.jumlah, mutasi_stock.type_mutasi, mutasi_stock.tgl_mutasi
        FROM mutasi_stock
        INNER JOIN product ON product.pcode = mutasi_stock.pcode
        GROUP BY mutasi_stock.id
        ORDER BY mutasi_stock.id DESC";
        $sql = $db->query($query)->getResult();
        return $sql;
    }

}
