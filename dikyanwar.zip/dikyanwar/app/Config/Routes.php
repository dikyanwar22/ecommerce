<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
// $routes->setDefaultNamespace('App\Controllers');
// $routes->setDefaultController('Home');

$routes->setDefaultNamespace('App\Controllers\admin');
$routes->setDefaultController('Dashboard');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();

use App\Controllers\Login;
use App\Controllers\Pengguna;
use App\Controllers\Admin\Dashboard;
use App\Controllers\Admin\Product;
use App\Controllers\Admin\Stock;
use App\Controllers\Admin\MutasiStock as Mutasi;
use App\Controllers\Admin\Promo;
use App\Controllers\Admin\Order;
use App\Controllers\Admin\Customer;

// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
// $routes->get('/', 'Home::index');

$routes->get('/', [Product::class, 'index']);

$routes->get('login', [Login::class, 'index']);
$routes->add('action_log', [Login::class, 'action_login']);
$routes->get('register', [Login::class, 'register']);
$routes->add('action_reg', [Login::class, 'action_register']);
$routes->get('logout', [Login::class, 'logout']);

$routes->get('pengguna', [Pengguna::class, 'index']);
$routes->add('pengguna-update/(:segment)', [Pengguna::class, 'update/$1']);

$routes->get('stok', [Stock::class, 'index']);
$routes->add('stok-update/(:segment)', [Stock::class, 'update/$1']);

$routes->get('mutasi', [Mutasi::class, 'index']);

$routes->get('order', [Order::class, 'index']);
$routes->add('order-produk', [Order::class, 'create']);

$routes->get('customer', [Customer::class, 'index']);
$routes->get('customer-orderid/(:segment)', [Customer::class, 'show/$1']);
$routes->add('customer-add', [Customer::class, 'create']);

$routes->group('produk', function($routes) {
    $routes->get('/', 'Product::index');
    $routes->add('store', 'Product::create');
    $routes->add('edit/(:segment)', 'Product::update/$1');
    $routes->get('delete/(:segment)', 'Product::destroy/$1');
});

$routes->group('promo', function($routes) {
    $routes->get('/', 'Promo::index');
    $routes->add('store', 'Promo::create');
    $routes->add('edit/(:segment)', 'Promo::update/$1');
    $routes->get('delete/(:segment)', 'Promo::destroy/$1');
});

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
