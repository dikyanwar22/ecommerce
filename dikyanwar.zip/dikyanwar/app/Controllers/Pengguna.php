<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Akun;

class Pengguna extends BaseController {

    public function index() {
        $data['title'] = 'Akun';
        return view('admin/akun',$data);
    }

    public function update($id) {
        $model = new Akun();
        session()->remove('nm');
        session()->remove('email');
        if($this->request->getPost('password') == "") {
            $model->update($id, [
                'nm' => $this->request->getPost('nm'),
                'email' => $this->request->getPost('email'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);
        } else {
            $model->update($id, [
                'nm' => $this->request->getPost('nm'),
                'email' => $this->request->getPost('email'),
                'password' => md5($this->request->getPost('password')),
                'updated_at' => date('Y-m-d H:i:s')
            ]);
        }
        session()->set([
            'nm' => $this->request->getPost('nm'),
            'email' => $this->request->getPost('email'),
        ]);
        session()->setFlashdata('error', 'Update Profil berhasil');
        return redirect()->back();
    }

}
