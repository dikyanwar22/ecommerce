<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Akun;

class Login extends BaseController {
    
    public function index() {
        $data['title'] = 'Login';
        return view('login',$data);
    }

    public function action_login() {
        $model = new Akun();
        $email = $this->request->getPost('email');
        $password = md5($this->request->getVar('password'));
        $dataUser = $model->check_auth($email, $password);
        if ($dataUser) {
            session()->set([
                'id' => $dataUser->id,
                'nm' => $dataUser->nm,
                'email' => $dataUser->email,
                'logged_in' => TRUE
            ]);
            if($dataUser->level == '1') {
                return redirect()->to(base_url('produk'));
            } else {
                return redirect()->to(base_url('pembeli'));
            }
        } else {
            session()->setFlashdata('error', 'Username & Password Salah');
            return redirect()->back();
        }
    }
    
    public function register() {
        $data['title'] = 'Daftar Akun';
        return view('register',$data);
    }

    public function action_register() {
        $model = new Akun();
        $model->insert([
            'nm' => $this->request->getPost('nm'),
            'email' => $this->request->getPost('email'),
            'password' => md5($this->request->getVar('password')),
            'level' => 1,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        return redirect('login');
    }

    public function logout() {
        session()->destroy();
        return redirect()->to('/login');
    }

}
