<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\Stock as Stok;

class Stock extends BaseController
{
    public function index()
    {
        $model = new Stok();
        $data['title'] = 'Stok Produk';
        $data['stok'] = $model->db_stok();
        return view('admin/stok',$data);
    }

    public function update($id) {
        $model = new Stok();
        $model->update($id, [
            'jumlah' => $this->request->getPost('jumlah'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
        return redirect()->back();
    }

}
