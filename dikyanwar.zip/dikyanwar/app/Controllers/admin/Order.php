<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\Order as Beli;
use App\Models\Admin\MProduct;
use App\Models\Admin\Promo as ProdukPromo;
use App\Models\Admin\Customer;
use App\Models\Admin\OrderDetail;
use App\Models\Admin\MutasiStock;
use App\Models\Admin\Stock;

class Order extends BaseController {

    public function index() {
        $customer = new Customer();
        $model = new MProduct();
        $data['title'] = 'Order';
        $data['p'] = $model->findAll();
        $data['c'] = $customer->findAll();
        $data['validation'] = \Config\Services::validation();
        return view('admin/order',$data);
    }

    public function create() {
        if (!$this->validate([
            'customer_id' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nama Konsumen Harus diisi'
                ]
            ]
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        } else {

        $model = new Beli();
        $order_det = new OrderDetail();
        $mutasi_model = new MutasiStock();

        $promo_code = $this->request->getPost('promo_code');
        $check_kode_promo = $model->check_kode($promo_code);
        $amount_discount = $this->request->getPost('amount_discount');
        $net = $this->request->getPost('net');
        $ppn = $this->request->getPost('ppn');
        if($promo_code == "") {
            $total = $net - ($amount_discount + $ppn);
        } else {
            $pot_promo = $check_kode_promo->potongan ?? 0;
            $total = $net - ($amount_discount + $ppn + $pot_promo);
        }
        //membuat kode order
        $kode = $model->order_code();
        $urutan = $kode->kodeTerbesar;
        $no = substr($urutan, -6, 6);
        $no = (int) $no;
        $no += 1;
        $kode_order = 'INV'. '/'. date('m') . '/' . date('Y') . '/' . sprintf("%06s", $no);
        //INV/07/2020/00001
        //membuat kode order
        $model->insert([
            'order_id' => $kode_order,
            'order_date' => date('Y-m-d H:i:s'),
            'customer_id' => $this->request->getPost('customer_id'),
            'promo_code' => $check_kode_promo->potongan ?? null,
            'amount_discount' => $amount_discount,
            'net' => $net,
            'ppn' => $ppn,
            'total' => $total,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        $qty = $this->request->getPost('qty');
        $pcode = $this->request->getPost('pcode');
        $order_det->insert([
            'order_id' => $kode_order,
            'pcode' => $pcode,
            'qty' => $qty,
            'price' => $net,
            'subtotal' => $qty * $net,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        $mutasi_model->insert([
            'tgl_mutasi' => date('Y-m-d'),
            'pcode' => $pcode,
            'order_id' => $kode_order,
            'type_mutasi' => 'O',
            'jumlah' => $qty,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        //ubah data stok
        $db = \Config\Database::connect();
        $model_stock = new Stock();
        $tb_stok = $model_stock->db_viewstock($pcode);
        $qty = $this->request->getPost('qty');
        $jumlah_stok = $tb_stok->jumlah - $qty;
        $data = [
            'jumlah' => $jumlah_stok,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $sql_update = $db->table('stock')->where('pcode',$pcode)->update($data);
        //ubah data stok
        
        return redirect()->back();
    }
    }

}
