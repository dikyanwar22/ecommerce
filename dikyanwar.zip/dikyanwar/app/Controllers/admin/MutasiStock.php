<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\MutasiStock as Mutasi;

class MutasiStock extends BaseController
{
    public function index()
    {
        $model = new Mutasi();
        $data['title'] = 'Mutasi Stok';
        $data['mut'] = $model->db_mutasi();
        return view('admin/mutasi',$data);
    }
}
