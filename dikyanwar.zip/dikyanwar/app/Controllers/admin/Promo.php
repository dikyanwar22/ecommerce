<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\Promo as ProdukPromo;

class Promo extends BaseController {

    public function index() {
        $model = new ProdukPromo();
        $data['title'] = 'Promo';
        $data['p'] = $model->findAll();
        return view('admin/promo',$data);
    }

    public function create() {
        $model = new ProdukPromo();
        $model->insert([
            'promo_code' => $this->request->getPost('promo_code'),
            'promo_name' => $this->request->getPost('promo_name'),
            'potongan' => $this->request->getPost('potongan'),
            'created_at' => date('Y-m-d H:i:s')
        ]);
        return redirect()->back();
    }

    public function update($id) {
        $model = new ProdukPromo();
        $model->update($id, [
            'promo_code' => $this->request->getPost('promo_code'),
            'promo_name' => $this->request->getPost('promo_name'),
            'potongan' => $this->request->getPost('potongan'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
        return redirect()->back();
    }

    public function destroy($id) {
        $model = new ProdukPromo();
        $delete = $model->find($id);
        if($delete) {
            $model->delete($id);
            return redirect()->back();
        } else {
            return redirect()->back();
        }
    }
    
}
