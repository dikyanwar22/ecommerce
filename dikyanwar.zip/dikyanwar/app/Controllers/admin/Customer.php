<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\Customer as Konsumen;

class Customer extends BaseController {

    public function index() {
        $model = new Konsumen();
        $data['title'] = 'Konsumen';
        $data['k'] = $model->findAll();
        return view('admin/customer',$data);
    }

    public function create() {
        $model = new Konsumen();
        $model->insert([
            'customer_name' => $this->request->getPost('customer_name'),
            'address' => $this->request->getPost('address'),
            'created_at' => date('Y-m-d H:i:s')
        ]);
        return redirect()->back();
    }

    public function show($order_id) {
        $model = new Konsumen();
        $data['title'] = 'Konsumen';
        $data['k'] = $model->order_detail($order_id);
        return view('admin/customer_order',$data);
    }

}
