<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\MProduct;
use App\Models\Admin\Stock as Stok;

class Product extends BaseController {

    public function index() {
        $model = new MProduct();
        $data['title'] = 'Produk';
        $data['p'] = $model->findAll();
        return view('admin/produk',$data);
    }

    public function create() {
        $model = new MProduct();
        $stok_model = new Stok();

        $kode = $model->create_code();
        $urutan = $kode->kodeTerbesar;
        $no = substr($urutan, -6, 6);
        $no = (int) $no;
        $no += 1;
        $pcode = sprintf("%06s", $no);
       
        $model->insert([
            'pcode' => $pcode,
            'product_name' => $this->request->getPost('product_name'),
            'price' => $this->request->getPost('price'),
            'created_at' => date('Y-m-d H:i:s')
        ]);

        $stok_model->insert([
            'pcode' => $pcode,
            'jumlah' => '1',
            'created_at' => date('Y-m-d H:i:s')
        ]);
        return redirect('produk');
    }

    public function update($id) {
        $model = new MProduct();
        $model->update($id, [
            'product_name' => $this->request->getPost('product_name'),
            'price' => $this->request->getPost('price'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
        return redirect('produk');
    }

    public function destroy($id) {
        $model = new MProduct();
        $delete = $model->find($id);
        if($delete) {
            $model->delete($id);
            return redirect('produk');
        } else {
            return redirect('produk');
        }
    }
}
