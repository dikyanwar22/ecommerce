-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2023 at 10:34 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) UNSIGNED NOT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Paijo', 'Jl. Kutilang berkicau 12, jakarta barat', '2023-03-15 04:25:50', '2023-03-16 04:25:50'),
(2, 'Diky Anwar', 'Jl GKBI Plumbon Ds Pesanggrahan Kec Plumbon Kab Cirebon', '2023-03-25 21:51:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2023-03-24-095409', 'App\\Database\\Migrations\\Mproduct', 'default', 'App', 1679703570, 1),
(3, '2023-03-25-021515', 'App\\Database\\Migrations\\Akun', 'default', 'App', 1679716647, 2),
(4, '2023-03-26-010612', 'App\\Database\\Migrations\\Customer', 'default', 'App', 1679795031, 3),
(5, '2023-03-26-010623', 'App\\Database\\Migrations\\Stock', 'default', 'App', 1679795032, 3),
(6, '2023-03-26-010633', 'App\\Database\\Migrations\\MutasiStock', 'default', 'App', 1679795095, 4),
(7, '2023-03-26-010634', 'App\\Database\\Migrations\\Order', 'default', 'App', 1679795096, 4),
(8, '2023-03-26-010635', 'App\\Database\\Migrations\\OrderDetail', 'default', 'App', 1679795097, 4),
(9, '2023-03-26-010636', 'App\\Database\\Migrations\\Promo', 'default', 'App', 1679795098, 4);

-- --------------------------------------------------------

--
-- Table structure for table `mutasi_stock`
--

CREATE TABLE `mutasi_stock` (
  `id` int(11) NOT NULL,
  `tgl_mutasi` date DEFAULT NULL,
  `pcode` varchar(255) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `type_mutasi` varchar(255) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mutasi_stock`
--

INSERT INTO `mutasi_stock` (`id`, `tgl_mutasi`, `pcode`, `order_id`, `type_mutasi`, `jumlah`, `created_at`, `updated_at`) VALUES
(1, '2023-03-26', '000001', '20230326073937', 'O', 1, '2023-03-26 00:39:37', NULL),
(2, '2023-03-26', '000001', 'INV/03/2023/000001', 'O', 1, '2023-03-26 01:24:31', NULL),
(3, '2023-03-26', '000001', 'INV/03/2023/000001', 'O', 2, '2023-03-26 01:30:03', NULL),
(4, '2023-03-26', '000001', 'INV/03/2023/000002', 'O', 1, '2023-03-26 01:31:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `order_detail_id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `pcode` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `subtotal` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`order_detail_id`, `order_id`, `pcode`, `qty`, `price`, `subtotal`, `created_at`, `updated_at`) VALUES
(3, 'INV/03/2023/000001', '000001', 2, 20000, 40000, '2023-03-26 01:30:03', NULL),
(4, 'INV/03/2023/000002', '000001', 1, 20000, 20000, '2023-03-26 01:31:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_header`
--

CREATE TABLE `order_header` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `promo_code` varchar(255) DEFAULT NULL,
  `amount_discount` float DEFAULT NULL,
  `net` float DEFAULT NULL,
  `ppn` float DEFAULT NULL,
  `total` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_header`
--

INSERT INTO `order_header` (`id`, `order_id`, `order_date`, `customer_id`, `promo_code`, `amount_discount`, `net`, `ppn`, `total`, `created_at`, `updated_at`) VALUES
(3, 'INV/03/2023/000001', '2023-03-26', 1, NULL, 1000, 20000, 1900, 17100, '2023-03-26 01:30:03', NULL),
(4, 'INV/03/2023/000002', '2023-03-26', 2, '1000', 1000, 20000, 1900, 16100, '2023-03-26 01:31:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `pcode` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `pcode`, `product_name`, `price`, `created_at`, `updated_at`) VALUES
(1, '000001', 'MIRANDA H.C N.BLACK 30.MC1', 20000, '2023-03-26 01:29:24', '2023-03-26 01:29:24'),
(5, '000002', 'HP Samsung', 700000, '2023-03-26 01:33:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `promo`
--

CREATE TABLE `promo` (
  `id` int(11) NOT NULL,
  `promo_code` varchar(255) DEFAULT NULL,
  `promo_name` text DEFAULT NULL,
  `potongan` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `promo`
--

INSERT INTO `promo` (`id`, `promo_code`, `promo_name`, `potongan`, `created_at`, `updated_at`) VALUES
(2, 'pmo-001', 'Setiap pembelian MIRANDA H.C N.BLACK 30.MC1, mendapat porongan 1000', 1000, '2023-03-26 01:16:04', '2023-03-26 01:31:08');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) UNSIGNED NOT NULL,
  `pcode` varchar(255) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `pcode`, `jumlah`, `created_at`, `updated_at`) VALUES
(1, '000001', -4, '2023-03-26 00:34:51', '2023-03-26 01:31:32'),
(2, '000002', 1, '2023-03-26 00:35:02', NULL),
(3, '000003', 1, '2023-03-26 01:12:03', NULL),
(4, '000004', 1, '2023-03-26 01:12:36', NULL),
(5, '000002', 1, '2023-03-26 01:33:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `nm` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `level` enum('1','2') DEFAULT '2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nm`, `email`, `password`, `level`, `created_at`, `updated_at`) VALUES
(1, 'Diky Anwar', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '2023-03-24 20:58:25', '2023-03-25 20:00:55'),
(7, 'Diky Anwar', 'dikyanwar22@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '2023-03-26 00:52:32', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mutasi_stock`
--
ALTER TABLE `mutasi_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`order_detail_id`);

--
-- Indexes for table `order_header`
--
ALTER TABLE `order_header`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `promo`
--
ALTER TABLE `promo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `mutasi_stock`
--
ALTER TABLE `mutasi_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `order_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_header`
--
ALTER TABLE `order_header`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `promo`
--
ALTER TABLE `promo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
